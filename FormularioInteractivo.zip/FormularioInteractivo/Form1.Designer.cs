﻿namespace FormularioInteractivo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelEstado = new System.Windows.Forms.Label();
            this.textBoxDigitos = new System.Windows.Forms.TextBox();
            this.panelImagen = new System.Windows.Forms.Panel();
            this.buttonIniciar = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // labelEstado
            // 
            this.labelEstado.AutoSize = true;
            this.labelEstado.Location = new System.Drawing.Point(187, 153);
            this.labelEstado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelEstado.Name = "labelEstado";
            this.labelEstado.Size = new System.Drawing.Size(151, 25);
            this.labelEstado.TabIndex = 0;
            this.labelEstado.Text = "Estado: Inactivo";
            // 
            // textBoxDigitos
            // 
            this.textBoxDigitos.Location = new System.Drawing.Point(192, 193);
            this.textBoxDigitos.Name = "textBoxDigitos";
            this.textBoxDigitos.Size = new System.Drawing.Size(146, 30);
            this.textBoxDigitos.TabIndex = 1;
            
            // 
            // panelImagen
            // 
            this.panelImagen.AllowDrop = true;
            this.panelImagen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelImagen.Location = new System.Drawing.Point(463, 101);
            this.panelImagen.Name = "panelImagen";
            this.panelImagen.Size = new System.Drawing.Size(305, 257);
            this.panelImagen.TabIndex = 2;
            // 
            // buttonIniciar
            // 
            this.buttonIniciar.Location = new System.Drawing.Point(192, 309);
            this.buttonIniciar.Name = "buttonIniciar";
            this.buttonIniciar.Size = new System.Drawing.Size(133, 35);
            this.buttonIniciar.TabIndex = 0;
            this.buttonIniciar.Text = "Iniciar Timer";
            this.buttonIniciar.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 500);
            this.Controls.Add(this.buttonIniciar);
            this.Controls.Add(this.panelImagen);
            this.Controls.Add(this.textBoxDigitos);
            this.Controls.Add(this.labelEstado);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelEstado;
        private System.Windows.Forms.TextBox textBoxDigitos;
        private System.Windows.Forms.Panel panelImagen;
        private System.Windows.Forms.Button buttonIniciar;
        private System.Windows.Forms.Timer timer1;
    }
}

