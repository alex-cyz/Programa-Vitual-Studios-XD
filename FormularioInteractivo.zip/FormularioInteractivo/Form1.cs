﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace FormularioInteractivo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            
            labelEstado.Click += (s, e) =>
            {
                labelEstado.Text = "Estado: Activo";
            };

            
            textBoxDigitos.KeyPress += (s, e) =>
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            };

            
            panelImagen.DragEnter += (s, e) =>
            {
                if (e.Data.GetDataPresent(DataFormats.FileDrop))
                {
                    string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                    if (files.Length > 0 && EsImagen(files[0]))
                        e.Effect = DragDropEffects.Copy;
                }
            };

            
            panelImagen.DragDrop += (s, e) =>
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length > 0 && EsImagen(files[0]))
                {
                    try
                    {
                        panelImagen.BackgroundImage = Image.FromFile(files[0]);
                        panelImagen.BackgroundImageLayout = ImageLayout.Zoom;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al cargar imagen: " + ex.Message);
                    }
                }
            };

            
            buttonIniciar.Click += (s, e) =>
            {
                timer1.Start();
                labelEstado.Text = "Timer iniciado";
            };

           
            timer1.Tick += (s, e) =>
            {
                labelEstado.Text = "Hora: " + DateTime.Now.ToLongTimeString();
            };
        }

        
        private bool EsImagen(string file)
        {
            string ext = Path.GetExtension(file).ToLower();
            return ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".bmp" || ext == ".gif";
        }
    }
}
